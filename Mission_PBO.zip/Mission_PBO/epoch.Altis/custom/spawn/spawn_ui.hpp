class spawn_ui
{
   idd = 2688;
   movingenable = false;
   
   class controls
   {


////////////////////////////////////////////////////////
// GUI EDITOR OUTPUT START (by rvg, v1.063, #Cymahi)
////////////////////////////////////////////////////////

class IGUIBack_2200: IGUIBack
{
	idc = 2200;
	x = -0.505469 * safezoneW + safezoneX;
	y = -0.149 * safezoneH + safezoneY;
	w = 1.52625 * safezoneW;
	h = 1.243 * safezoneH;
	colorBackground[] = {0,0,0,0.5};
};
class RscPicture_1200: RscPicture
{
	idc = 1200;
	text = "custom\images\spawn_map.jpg";
	x = 0.237031 * safezoneW + safezoneX;
	y = 0.104 * safezoneH + safezoneY;
	w = 0.513333 * safezoneW;
	h = 0.821444 * safezoneH;
};
class RscButton_1600: RscButton
{
	idc = 1600;
	text = ""; //--- ToDo: Localize;
	x = 0.287344 * safezoneW + safezoneX;
	y = 0.530666 * safezoneH + safezoneY;
	w = 0.041198 * safezoneW;
	h = 0.064037 * safezoneH;
	onButtonClick="""spawn_1"" spawn fnc_spawn;";
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "Click to teleport inside Spawnzone 1"; //--- ToDo: Localize;
};
class RscButton_1601: RscButton
{
	idc = 1601;
	text = ""; //--- ToDo: Localize;
	x = 0.307812 * safezoneW + safezoneX;
	y = 0.313889 * safezoneH + safezoneY;
	w = 0.041198 * safezoneW;
	h = 0.064037 * safezoneH;
	onButtonClick="""spawn_2"" spawn fnc_spawn;";
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "Click to teleport inside Spawnzone 2"; //--- ToDo: Localize;
};
class RscButton_1602: RscButton
{
	idc = 1602;
	text = ""; //--- ToDo: Localize;
	x = 0.370834 * safezoneW + safezoneX;
	y = 0.380556 * safezoneH + safezoneY;
	w = 0.072448 * safezoneW;
	h = 0.123296 * safezoneH;
	onButtonClick="""spawn_3"" spawn fnc_spawn;";
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "Click to teleport inside Spawnzone 3"; //--- ToDo: Localize;
};
class RscButton_1603: RscButton
{
	idc = 1603;
	text = ""; //--- ToDo: Localize;
	x = 0.408333 * safezoneW + safezoneX;
	y = 0.549074 * safezoneH + safezoneY;
	w = 0.041198 * safezoneW;
	h = 0.064037 * safezoneH;
	onButtonClick="""spawn_4"" spawn fnc_spawn;";
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "Click to teleport inside Spawnzone 4"; //--- ToDo: Localize;
};
class RscButton_1604: RscButton
{
	idc = 1604;
	text = ""; //--- ToDo: Localize;
	x = 0.488541 * safezoneW + safezoneX;
	y = 0.417593 * safezoneH + safezoneY;
	w = 0.041198 * safezoneW;
	h = 0.064037 * safezoneH;
	onButtonClick="""spawn_5"" spawn fnc_spawn;";
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "Click to teleport inside Spawnzone 5"; //--- ToDo: Localize;
};
class RscButton_1605: RscButton
{
	idc = 1605;
	text = ""; //--- ToDo: Localize;
	x = 0.514375 * safezoneW + safezoneX;
	y = 0.540296 * safezoneH + safezoneY;
	w = 0.0516147 * safezoneW;
	h = 0.0797778 * safezoneH;
	onButtonClick="""spawn_6"" spawn fnc_spawn;";
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "Click to teleport inside Spawnzone 6"; //--- ToDo: Localize;
};
class RscButton_1606: RscButton
{
	idc = 1606;
	text = ""; //--- ToDo: Localize;
	x = 0.565625 * safezoneW + safezoneX;
	y = 0.667593 * safezoneH + safezoneY;
	w = 0.0375523 * safezoneW;
	h = 0.0603334 * safezoneH;
	onButtonClick="""spawn_7"" spawn fnc_spawn;";
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "Click to teleport inside Spawnzone 7"; //--- ToDo: Localize;
};
class RscButton_1607: RscButton
{
	idc = 1607;
	text = ""; //--- ToDo: Localize;
	x = 0.579688 * safezoneW + safezoneX;
	y = 0.432407 * safezoneH + safezoneY;
	w = 0.0375523 * safezoneW;
	h = 0.0603334 * safezoneH;
	onButtonClick="""spawn_8"" spawn fnc_spawn;";
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "Click to teleport inside Spawnzone 8"; //--- ToDo: Localize;
};
class RscButton_1608: RscButton
{
	idc = 1608;
	text = ""; //--- ToDo: Localize;
	x = 0.64375 * safezoneW + safezoneX;
	y = 0.301851 * safezoneH + safezoneY;
	w = 0.0375523 * safezoneW;
	h = 0.0603334 * safezoneH;
	onButtonClick="""spawn_9"" spawn fnc_spawn;";
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "Click to teleport inside Spawnzone 9"; //--- ToDo: Localize;
};
class RscButton_1609: RscButton
{
	idc = 1609;
	text = "Exit"; //--- ToDo: Localize;
	x = 0.773281 * safezoneW + safezoneX;
	y = 0.478 * safezoneH + safezoneY;
	w = 0.0531773 * safezoneW;
	h = 0.0371852 * safezoneH;
	onbuttonclick="closedialog 2688;";
};
class RscStructuredText_1100: RscStructuredText
{
	idc = 1100;
	text = "<t size='1.5' color='#FF4000' align='center'>-= Select Your Spawnzone =-"; //--- ToDo: Localize;
	x = 0.273125 * safezoneW + safezoneX;
	y = 0.06 * safezoneH + safezoneY;
	w = 0.438281 * safezoneW;
	h = 0.055 * safezoneH;
	colorBackground[] = {0,0,0,0};
};
////////////////////////////////////////////////////////
// GUI EDITOR OUTPUT END
////////////////////////////////////////////////////////


   };
};