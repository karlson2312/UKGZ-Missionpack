class taskbar
{
   idd = 1388;
   movingenable = false;
   
   class controls
   {
////////////////////////////////////////////////////////
// GUI EDITOR OUTPUT START (by rvg?!, v1.063, #Cylifu)
////////////////////////////////////////////////////////

class IGUIBack_2200: IGUIBack
{
	idc = 2200;
	x = 0.298906 * safezoneW + safezoneX;
	y = -0.00599999 * safezoneH + safezoneY;
	w = 0.402187 * safezoneW;
	h = 0.154 * safezoneH;
	colorBackground[] = {0,0,0,0.4};
};
class RscStructuredText_1100: RscStructuredText
{
	idc = 1100;
	text = "<t size='1'><t color='#FF4000'>General"; //--- ToDo: Localize;
	x = 0.324687 * safezoneW + safezoneX;
	y = 0.016 * safezoneH + safezoneY;
	w = 0.0464063 * safezoneW;
	h = 0.033 * safezoneH;
	colorBackground[] = {0,0,0,0};
};
class RscButton_1600: RscButton
{
	idc = 1600;
	text = "Info"; //--- ToDo: Localize;
	x = 0.309219 * safezoneW + safezoneX;
	y = 0.049 * safezoneH + safezoneY;
	w = 0.0721875 * safezoneW;
	h = 0.033 * safezoneH;
	onButtonClick = "createDialog ""gui_welcome"";";
};
class RscStructuredText_1102: RscStructuredText
{
	idc = 1102;
	text = "<t size='1'><t color='#FF4000'>Ambient"; //--- ToDo: Localize;
	x = 0.453594 * safezoneW + safezoneX;
	y = 0.016 * safezoneH + safezoneY;
	w = 0.0515625 * safezoneW;
	h = 0.033 * safezoneH;
	colorBackground[] = {0,0,0,0};
};
class RscStructuredText_1101: RscStructuredText
{
	idc = 1101;
	text = "<t size='0.9'><t color='#FF4000'>Rescue Packages"; //--- ToDo: Localize;
	x = 0.597969 * safezoneW + safezoneX;
	y = 0.016 * safezoneH + safezoneY;
	w = 0.0876563 * safezoneW;
	h = 0.033 * safezoneH;
	colorBackground[] = {0,0,0,0};
};
class RscButton_1601: RscButton
{
	idc = 1601;
	text = "Endtime"; //--- ToDo: Localize;
	x = 0.402031 * safezoneW + safezoneX;
	y = 0.049 * safezoneH + safezoneY;
	w = 0.0721875 * safezoneW;
	h = 0.022 * safezoneH;
	onButtonClick = "[] call CC5;";
};
class RscButton_1602: RscButton
{
	idc = 1602;
	text = "Vietnam"; //--- ToDo: Localize;
	x = 0.402031 * safezoneW + safezoneX;
	y = 0.082 * safezoneH + safezoneY;
	w = 0.0721875 * safezoneW;
	h = 0.022 * safezoneH;
	onButtonClick = "[] call CC1;";
};
class RscButton_1603: RscButton
{
	idc = 1603;
	text = "Blazing Sun"; //--- ToDo: Localize;
	x = 0.402031 * safezoneW + safezoneX;
	y = 0.115 * safezoneH + safezoneY;
	w = 0.0721875 * safezoneW;
	h = 0.022 * safezoneH;
	onButtonClick = "[] call CC2;";
};
class RscButton_1604: RscButton
{
	idc = 1604;
	text = "Mediterranean"; //--- ToDo: Localize;
	x = 0.484531 * safezoneW + safezoneX;
	y = 0.049 * safezoneH + safezoneY;
	w = 0.0773437 * safezoneW;
	h = 0.022 * safezoneH;
	onButtonClick = "[] call CC3;";
};
class RscButton_1605: RscButton
{
	idc = 1605;
	text = "Bright Nights"; //--- ToDo: Localize;
	x = 0.484531 * safezoneW + safezoneX;
	y = 0.082 * safezoneH + safezoneY;
	w = 0.0773437 * safezoneW;
	h = 0.022 * safezoneH;
	onButtonClick = "[] call CC4;";
};
class RscButton_1606: RscButton
{
	idc = 1606;
	text = "Default"; //--- ToDo: Localize;
	x = 0.484531 * safezoneW + safezoneX;
	y = 0.115 * safezoneH + safezoneY;
	w = 0.0773437 * safezoneW;
	h = 0.022 * safezoneH;
	onButtonClick = "[] call CC6;";
};
class RscStructuredText_1104: RscStructuredText
{
	idc = 1607;
	text = "<t size='0.9'><a color='#2E9AFE' href='http://www.paypal.me/ukgz'> Click to DONATE</a>";
	x = 0.309219 * safezoneW + safezoneX;
	y = 0.104 * safezoneH + safezoneY;
	w = 0.0721875 * safezoneW;
	h = 0.033 * safezoneH;
};
class RscButton_1608: RscButton
{
	idc = 1608;
	text = "Exit"; //--- ToDo: Localize;
	x = 0.675312 * safezoneW + safezoneX;
	y = 0.159 * safezoneH + safezoneY;
	w = 0.0257812 * safezoneW;
	h = 0.033 * safezoneH;
	onButtonClick = "closeDialog 0";
};


//////////////////////// Silver
class RscPicture_1200: RscPicture
{
	idc = 1200;
	text = "custom\taskbar\crate1.jpg";
	x = 0.5825 * safezoneW + safezoneX;
	y = 0.049 * safezoneH + safezoneY;
	w = 0.0515625 * safezoneW;
	h = 0.088 * safezoneH;
};

class RscButton_1688: RscButton
{
	idc = 1688;
	x = 0.5825 * safezoneW + safezoneX;
	y = 0.049 * safezoneH + safezoneY;
	w = 0.0515625 * safezoneW;
	h = 0.088 * safezoneH;
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "10.000 Krypto - Only available once in a session!"; //--- ToDo: Localize;
	onButtonClick = "[] call silver";
};

//////////////////////// Gold
class RscPicture_1201: RscPicture
{
	idc = 1201;
	text = "custom\taskbar\crate2.jpg";
	x = 0.639219 * safezoneW + safezoneX;
	y = 0.049 * safezoneH + safezoneY;
	w = 0.0515625 * safezoneW;
	h = 0.088 * safezoneH;
};

class RscButton_1648: RscButton
{
	idc = 1648;
	x = 0.639219 * safezoneW + safezoneX;
	y = 0.049 * safezoneH + safezoneY;
	w = 0.0515625 * safezoneW;
	h = 0.088 * safezoneH;
	colorText[] = {0,0,0,0};
	colorActive[] = {0,0,0,0};
	colorDisabled[] = {0,0,0,0};
    colorBackground[] = {0,0,0,0};
    colorBackgroundDisabled[] = {0,0,0,0};
    colorBackgroundActive[] = {0,0,0,0};
    colorFocused[] = {0,0,0,0};
    colorShadow[] = {0,0,0,0};
    colorBorder[] = {0,0,0,0};
	tooltip = "20.000 Krypto - Only available once in a session!"; //--- ToDo: Localize;
	onButtonClick = "[] call gold";
};
////////////////////////////////////////////////////////
// GUI EDITOR OUTPUT END
////////////////////////////////////////////////////////


   };
};
