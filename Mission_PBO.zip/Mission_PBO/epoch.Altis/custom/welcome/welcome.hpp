class gui_welcome
{
   idd = 1588;
   movingenable = false;
   
   class controls
   {

class IGUIBack_2200: IGUIBack
{
	idc = 2200;
	x = 0.180312 * safezoneW + safezoneX;
	y = 0.115 * safezoneH + safezoneY;
	w = 0.623906 * safezoneW;
	h = 0.759 * safezoneH;
	colorBackground[] = {0,0,0,0.4};
};
class IGUIBack_2201: IGUIBack
{
	idc = 2201;
	x = 0.206094 * safezoneW + safezoneX;
	y = 0.159 * safezoneH + safezoneY;
	w = 0.572344 * safezoneW;
	h = 0.319 * safezoneH;
	colorBackground[] = {0,0,0,0.5};
};
class IGUIBack_2202: IGUIBack
{
	idc = 2202;
	x = 0.572188 * safezoneW + safezoneX;
	y = 0.489 * safezoneH + safezoneY;
	w = 0.20625 * safezoneW;
	h = 0.352 * safezoneH;
	colorBackground[] = {0,0,0,0.5};
};
class IGUIBack_2203: IGUIBack
{
	idc = 2203;
	x = 0.206094 * safezoneW + safezoneX;
	y = 0.489 * safezoneH + safezoneY;
	w = 0.360937 * safezoneW;
	h = 0.352 * safezoneH;
	colorBackground[] = {0,0,0,0.5};
};
class RscStructuredText_1100: RscStructuredText
{
	idc = 1100;
	text = "<t size='1.5' color='#FF4000' align='center'>-=Welcome to [UKGZ] Epoch Xtreme=-<br/><br/><br/><t size='1' color='#FFFFFF' align='center'> Hi survivor!<br/>We've added this news window to keep you informed about the recent changes here and on our other servers.<br/>Please report bugs or ideas on our forums at: <a color='#2E9AFE' href='http://www.ukgz.eu'>www.ukgz.eu</a><br/><br/>Enjoy your stay!<br/><br/><br/><t size='1' color='#00FFFF' align='center'>Help us to keep the server alive!<br/><a color='#2E9AFE' href='http://www.paypal.me/ukgz'> Click here to DONATE with PayPal</a>"; //--- ToDo: Localize;
	x = 0.21125 * safezoneW + safezoneX;
	y = 0.181 * safezoneH + safezoneY;
	w = 0.556875 * safezoneW;
	h = 0.286 * safezoneH;
	colorBackground[] = {0,0,0,0};
};
class RscStructuredText_1101: RscStructuredText
{
	idc = 1101;
	text = "<t size='1.2' color='#FFFF00' align='center'>Changelog 29.07.2016<br/><br/><t size='1' color='#FFFFFF' align='left'>- Added RyanZombies<br/>- Removed vehicles from Blackmarket<br/>- Tox causes visual effect<br/>- New icon Autolockpick<br/>- New icon Baseprotection<br/>- Vehicle lock set to 48h<br/>- Bank Transfer SpeedUP<br/>- RMS Earthquakes overhaul<br/>- RMS SupplyDrops overhaul<br/>- RMS Crashsites overhaul<br/>"; //--- ToDo: Localize;
	x = 0.577344 * safezoneW + safezoneX;
	y = 0.5 * safezoneH + safezoneY;
	w = 0.195937 * safezoneW;
	h = 0.33 * safezoneH;
	colorBackground[] = {0,0,0,0};
};
class RscStructuredText_1102: RscStructuredText
{
	idc = 1102;
	text = "<t size='1.2' color='FFFF00' align='center'>READ THE RULES!<br/><br/><t size='1'  color='FFFFFF' align='left'>* GERMAN/ENGLISH ONLY IN SIDECHAT.<br/>* NO HACKING, EXPLOITING OR GLITCHING.<br/>* NO COMBAT LOGGING.<br/>* NO DROPPING VEHICLES AS BOMBS FROM HELICOPTERS.<br/>* NO STORING VEHICLES AT SAFEZONES.<br/>* NO STEALING FROM SAFEZONES.<br/>* DO NOT KAMIKAZE WITH HELIS.<br/>* NO BUILDING ON FUEL STATIONS.<br/>* NO BUILDING NEAR SAFEZONES (1000m).<br/>* NO BUILDING IN MILITARY BASES.<br/>* NO VOICE IN SIDECHANNEL.<br/>* NO RACISM.<t/>"; //--- ToDo: Localize;
	x = 0.21125 * safezoneW + safezoneX;
	y = 0.5 * safezoneH + safezoneY;
	w = 0.350625 * safezoneW;
	h = 0.33 * safezoneH;
	colorBackground[] = {0,0,0,0};
};
class RscButton_1600: RscButton
{
	idc = 1600;
	text = "Exit"; //--- ToDo: Localize;
	x = 0.814531 * safezoneW + safezoneX;
	y = 0.434 * safezoneH + safezoneY;
	w = 0.04125 * safezoneW;
	h = 0.044 * safezoneH;
	onButtonClick="closedialog 0;";
};
class RscPicture_1200: RscPicture
{
	idc = 1200;
	text = "custom\welcome\ukgz.jpg";
	x = 0.21125 * safezoneW + safezoneX;
	y = 0.17 * safezoneH + safezoneY;
	w = 0.108281 * safezoneW;
	h = 0.099 * safezoneH;
	colorBackground[] = {0,0,0,0};
};
class RscPicture_1201: RscPicture
{
	idc = 1201;
	text = "custom\welcome\paypal.jpg";
	x = 0.665 * safezoneW + safezoneX;
	y = 0.368 * safezoneH + safezoneY;
	w = 0.108281 * safezoneW;
	h = 0.099 * safezoneH;
	colorBackground[] = {0,0,0,0};
};

	};
};