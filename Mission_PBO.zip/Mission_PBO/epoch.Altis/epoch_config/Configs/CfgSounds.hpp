/*
	Author: Aaron Clark - EpochMod.com

    Contributors:

	Description:
	CfgSounds

    Licence:
    Arma Public License Share Alike (APL-SA) - https://www.bistudio.com/community/licenses/arma-public-license-share-alike

    Github:
    https://github.com/EpochModTeam/Epoch/tree/release/Sources/epoch_config/Configs/CfgSounds.hpp
*/
class CfgSounds
{
	class dog_bark
	{
		sound[] = { "@A3\Sounds_F\ambient\animals\dog1", 0.6, 1.0 };
		titles[] = {};
	};
	class dog_cry
	{
		sound[] = { "@A3\Sounds_F\ambient\animals\dog4", 0.6, 1.0 };
		titles[] = {};
	};
	class hed_cluck0
	{
		sound[] = { "@A3\Sounds_F\ambient\animals\hen1", 0.3, 1.0 };
		titles[] = {};
	};
	class hed_cluck1
	{
		sound[] = { "@A3\Sounds_F\ambient\animals\hen2", 0.3, 1.0 };
		titles[] = {};
	};
	class hed_cluck2
	{
		sound[] = { "@A3\Sounds_F\ambient\animals\hen3", 0.3, 1.0 };
		titles[] = {};
	};
	class cultist_talk
	{
		sound[] = { "@x\addons\a3_epoch_assets\sounds\cloak\cultist_banter1", 0.7, 1.0 };
		titles[] = {};
	};
	class cultist_death
	{
		sound[] = { "@x\addons\a3_epoch_assets\sounds\cloak\cultist_death", 0.7, 1.0 };
		titles[] = {};
	};
	class cultist_laugh
	{
		sound[] = { "@x\addons\a3_epoch_assets\sounds\cloak\cultist_laugh", 0.7, 1.0 };
		titles[] = {};
	};
	class cultist_nearby
	{
		sound[] = { "@x\addons\a3_epoch_assets\sounds\cloak\cultist_nearby", 0.7, 1.0 };
		titles[] = {};
	};
	class cultist_taunt
	{
		sound[] = { "@x\addons\a3_epoch_assets\sounds\cloak\cultist_taunt", 0.7, 1.0 };
		titles[] = {};
	};
		class shocker
	{
		name = "electrocute";
		sound[] = {custom\sounds\electrocute.ogg, 1, 1};
		titles[] = {};
	};
	
		class rms_sandstorm
	{
		name = "rms_sandstorm";
		sound[] = {custom\sounds\rms_sandstorm.ogg, 1, 1};
		titles[] = {};
	};
	
		class nuclear_geiger
	{
		name = "geiger";
		sound[] = {custom\sounds\geiger.ogg, 1, 1};
		titles[] = {};
	};
	
		class earplugs_out
	{
		name = "earplugs_out";
		sound[] = {custom\earplugs\earplugs_out.ogg, 1, 1};
		titles[] = {};
	};
	
		class jungle_1
	{
		name = "jungle_1";
		sound[] = {custom\welcome\sounds\jungle_1.ogg, 1, 1};
		titles[] = {};
	};
	
		class jungle_2
	{
		name = "jungle_2";
		sound[] = {custom\welcome\sounds\jungle_2.ogg, 1, 1};
		titles[] = {};
	};
	
		class jungle_3
	{
		name = "jungle_3";
		sound[] = {custom\welcome\sounds\jungle_3.ogg, 1, 1};
		titles[] = {};
	};
};
