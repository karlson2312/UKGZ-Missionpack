/*
	Author: Aaron Clark - EpochMod.com

    Contributors:

	Description:
	Epoch gamemode config for Altis

    Licence:
    Arma Public License Share Alike (APL-SA) - https://www.bistudio.com/community/licenses/arma-public-license-share-alike

    Github:
    https://github.com/EpochModTeam/Epoch/tree/master/Sources/epoch_config/Configs/CfgEpochClient/Altis.hpp
*/

class Tanoa {
	blockedArea[] = { //[POS],radius
			// Flughäfen
				{ { 7073,7387,0 }, 700 }, 		//Aeroport de Tanoa
				{ { 11840,13133,0 }, 550 }, 	//La Rochelle Aerodrome
				{ { 11422,3297,0 }, 250 }, 		//Lijnhaven Airport 1
				{ { 11552,3219,0 }, 250 }, 		//Lijnhaven Airport 3
				{ { 11787,3044,0 }, 250 }, 		//Lijnhaven Airport 4
				{ { 11905, 2957,0 }, 250 }, 	//Lijnhaven Airport 5
				{ { 2190,3542,0 }, 500 }, 		//Bala Airstrip
				{ { 1969,13097,0 }, 300 }, 		//Tuvanaka Airbase 1
				{ { 2239,13322,0 }, 300 }, 		//Tuvanaka Airbase 2
	
			// Große Umgebungsobjekte
				{ { 7440,8519,0 }, 350 }, 		//Lufou Facotory
				{ { 13686,12106,0 }, 800 }, 	//Blue Pearl Industrial Port
				{ { 10030,11780,0 }, 100 }, 	//Vulkan Observatorium
				{ { 11064,8472,0 }, 150 }, 		//Temple Ruiuns
				{ { 12106,2482,0 }, 200 }, 		//Fortress Ruins
				{ { 11343,5617,0 }, 600 }, 		//Harcourt Bridge
				{ { 4379,5434,0 }, 600 }, 		//Yanukka Bridge
				{ { 8356,10326,0 }, 600 }, 		//Tanoa Sugar Company
	
			// Städte
				{ { 6374,12801,0 }, 250 }, 		//Nicolet
				{ { 5873,11038,0 }, 500 },  	//Saint-Julien
				{ { 5781,10210,0 }, 600 }, 		//Georgetown
				{ { 5085,8678,0 }, 400 }, 		//Regina
				{ { 12818,7359,0 }, 300 }, 		//Oumere
				{ { 5526,4030,0 }, 350 }, 		//Katkoula
				{ { 1821,11994,0 }, 200 }, 		//Tuvanaka
				{ { 936,7698,0 }, 250 }, 		//Tavu
				{ { 11810,2542,0 }, 500 }, 		//Lijnhaven
				{ { 12988,2120.9,0 }, 150 }, 	//Rereki
				{ { 9950,13499,0 }, 400 }, 		//La Rochelle 1
				{ { 9568,13534,0 }, 400 }, 		//La Rochelle 2
				{ { 9254,13716,0 }, 400 }, 		//La Rochelle 3
				{ { 8869,13753,0 }, 400 }, 		//La Rochelle 4
				{ { 8350,13753,0 }, 400 }, 		//La Rochelle 5
			
			// Spawnpunkte
				{ { 8852,10190,0 }, 350 }, 		//Tanouka
				{ { 2699,7379,0 }, 300 }, 		//Balavu
				{ { 9440,4050,0 }, 250 }, 		//Moddergat
				{ { 3065,11142,0 }, 250 }, 		//Belfort
				
				{ { 12713,3256,0 }, 150 }, 		//Port Boise
				{ { 13316,2956,0 }, 150 },		//Bua Bua
				{ { 12785,4793,0 }, 150 }, 		//Doodstil
				{ { 12376,4516,0 }, 150 }, 		//Saioko
				{ { 10178,5026,0 }, 150 }, 		//Lösi
				{ { 10370,2677,0 }, 150 }, 		//Blerick
				{ { 2954,3432,0 }, 200 }, 		//Yannuka
				{ { 3243,3363,0 }, 200 }, 		//Yannuka
				{ { 3421,6697,0 }, 200 }, 		//Rautake
				{ { 3793,13987,0 }, 100 }, 		//lagerreste1
				{ { 3928,13880,0 }, 100 }, 		//lagerreste2
				{ { 5730,12586,0 }, 150 }, 		//Oua-Oue
				{ { 11012,9701,0 }, 250 }, 		//Vagalala
				{ { 10869,6327,0 }, 250 }, 		//Harcourt Nord
				{ { 13966,8322,0 }, 200 }, 		//Luganville
				{ { 14429,8881,0 }, 100 } 		//Nandai
	};
	// Trash config
	TrashClasses[] = { "Trash", "TrashSmall", "TrashVehicle", "PumpkinPatch", "TrashFood", "HempFiber" };
};
