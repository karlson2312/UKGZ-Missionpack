class ItemEmptyTin { 
    price = 1;
};
class ItemSodaEmpty { 
    price = 1;
};
class ItemSodaAlpineDude { 
    price = 5;
};
class ItemHotwire { 
    price = 15;
};
class ItemKeyKit { 
    price = 15;
};
class ItemBarrelF { 
    price = 200;
};
class ItemBarrelE { 
    price = 50;
};
class ItemPipe { 
    price = 10;
};
class ItemKey { 
    price = 10;
};
class ItemKeyBlue { 
    price = 10;
};
class ItemKeyGreen { 
    price = 10;
};
class ItemKeyRed { 
    price = 10;
};
class ItemKeyYellow { 
    price = 10;
};
class ItemDoc1 { 
    price = 10;
};
class ItemDoc2 { 
    price = 10;
};
class ItemDoc3 { 
    price = 10;
};
class ItemDoc4 { 
    price = 10;
};
class ItemDoc5 { 
    price = 10;
};
class ItemDoc6 { 
    price = 10;
};
class ItemDoc7 { 
    price = 10;
};
class ItemDoc8 { 
    price = 10;
};
class ItemVehDoc1 { 
    price = 10;
};
class ItemVehDoc2 { 
    price = 10;
};
class ItemVehDoc3 { 
    price = 10;
};
class ItemVehDoc4 { 
    price = 10;
};
class ItemBulb { 
    price = 10;
};
class ItemBurlap { 
    price = 10;
};
class ItemBriefcaseE { 
    price = 10;
};
class ItemBriefcaseGold100oz { 
    price = 10000;
};
class ItemAluminumBar { 
    price = 10;
};
class ItemCopperBar { 
    price = 100;
};
class ItemTinBar { 
    price = 1;
};
class ItemPlywoodPack { 
    price = 100;
};
class ItemComboLock { 
    price = 45;
};
class Item_AssaultPack_cbr { 
    price = 10;
};
class Item_AssaultPack_dgtl { 
    price = 10;
};
class Item_AssaultPack_khk { 
    price = 10;
};
class Item_AssaultPack_mcamo { 
    price = 10;
};
class Item_AssaultPack_ocamo { 
    price = 10;
};
class Item_AssaultPack_rgr { 
    price = 10;
};
class Item_AssaultPack_sgg { 
    price = 10;
};
class Item_AssaultPack_blk { 
    price = 10;
};
class Item_Carryall_cbr { 
    price = 40;
};
class Item_Carryall_khk { 
    price = 40;
};
class Item_Carryall_mcamo { 
    price = 40;
};
class Item_Carryall_ocamo { 
    price = 40;
};
class Item_Carryall_oli { 
    price = 40;
};
class Item_Carryall_oucamo { 
    price = 40;
};
class Item_FieldPack_blk { 
    price = 15;
};
class Item_FieldPack_cbr { 
    price = 15;
};
class Item_FieldPack_khk { 
    price = 15;
};
class Item_FieldPack_ocamo { 
    price = 15;
};
class Item_FieldPack_oli { 
    price = 15;
};
class Item_FieldPack_oucamo { 
    price = 15;
};
class Item_Kitbag_cbr { 
    price = 25;
};
class Item_Kitbag_mcamo { 
    price = 25;
};
class Item_Kitbag_rgr { 
    price = 25;
};
class Item_Kitbag_sgg { 
    price = 25;
};
class Item_TacticalPack_blk { 
    price = 20;
};
class Item_TacticalPack_mcamo { 
    price = 20;
};
class Item_TacticalPack_ocamo { 
    price = 20;
};
class Item_TacticalPack_oli { 
    price = 20;
};
class Item_TacticalPack_rgr { 
    price = 20;
};
class Item_smallbackpack_red { 
    price = 22;
};
class Item_smallbackpack_green { 
    price = 22;
};
class Item_smallbackpack_teal { 
    price = 22;
};
class Item_smallbackpack_pink { 
    price = 22;
};
