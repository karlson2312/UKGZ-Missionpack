
class HSPricing
{

	class CircuitParts {price = 50;}; //
	class ItemCoolerE {price = 50;}; //
	class JackKit {price = 25;}; //
	class ItemLockbox {price = 250; tax = 0.5;}; //
	class ItemSafe { price = 1250; tax = 0.5; }; //
	class ItemCompass {price = 3;}; //
	class ItemGPS {price = 20;}; //

	// Radios
	class EpochRadio0 {price = 2;}; //
	class EpochRadio1 {price = 4;}; //
	class EpochRadio2 {price = 6;}; //
	class EpochRadio3 {price = 8;}; //
	class EpochRadio4 {price = 10;}; //
	class EpochRadio5 {price = 12;}; //
	class EpochRadio6 {price = 14;}; //
	class EpochRadio7 {price = 16;}; //
	class EpochRadio8 {price = 18;}; //
	class EpochRadio9 {price = 20;}; //

	class VehicleRepair {price = 35;}; //
	class VehicleRepairLg {price = 50;}; //

	class WhiskeyNoodle {price = 80;}; //

	class ItemWatch {price = 2;}; //

	class Binocular {price = 4;}; //
	class NVG_EPOCH {price = 35;}; //
	class acc_flashlight {price = 5;}; //
	class acc_pointer_IR {price = 5;}; //


	// Paint
	class PaintCanClear {price = 1;}; //
	class PaintCanBlk {price = 1;}; //
	class PaintCanBlu {price = 1;}; //
	class PaintCanBrn {price = 1;}; //
	class PaintCanGrn {price = 1;}; //
	class PaintCanOra {price = 1;}; //
	class PaintCanPur {price = 1;}; //
	class PaintCanRed {price = 1;}; //
	class PaintCanTeal {price = 1;}; //
	class PaintCanYel {price = 1;}; //

	class ItemDocument {price = 5;}; //
	class ItemDocumentMission {price = 5;}; //
	class ItemMixOil {price = 5;}; //
	class emptyjar_epoch {price = 5;}; //
	class jerrycan_epoch { price = 10; }; //
	class jerrycanE_epoch { price = 5; }; //
	class lighter_epoch { price = 50; }; //
	class WoodLog_EPOCH { price = 1; }; //
	class ItemRope { price = 5; }; //
	class ItemStick { price = 1; }; //
	class ItemRock { price = 1; }; //

	// Food
	class honey_epoch {price = 5;}; //
	class FoodBioMeat {price = 4;}; //
	class FoodMeeps {price = 50;}; //
	class FoodSnooter {price = 5;}; //
	class sardines_epoch {price = 2;}; //
	class meatballs_epoch {price = 2;}; //
	class scam_epoch {price = 4;}; //
	class TacticalBacon {price = 5;}; //
	class sweetcorn_epoch {price = 2;}; //
	class CookedSheep_EPOCH {price = 5;}; //
	class CookedGoat_EPOCH {price = 5;}; //
	class SnakeMeat_EPOCH {price = 3;}; //
	class CookedRabbit_EPOCH {price = 5;}; //
	class CookedChicken_EPOCH {price = 3;}; //
	class ItemTrout {price = 2;}; //
	class ItemTroutCooked {price = 20;}; //
	class ItemSeaBass {price = 5;}; //
	class ItemSeaBassCooked {price = 50;}; //
	class ItemTuna {price = 10;}; //
	class ItemTunaCooked {price = 100;}; //

	// Drinks
	class FoodWalkNSons {price = 5;}; //
	class ItemSodaOrangeSherbet {price = 4;}; //
	class ItemSodaPurple {price = 5;}; //
	class ItemSodaMocha {price = 8;}; //
	class ItemSodaBurst {price = 4;}; //
	class ItemSodaRbull {price = 5;}; //
	class water_epoch {price = 5;}; //
	class clean_water_epoch {price = 10;}; //

	// Medical
	class FAK {price = 3;}; //
	class Towelette {price = 1;}; //
	class HeatPack {price = 2;}; //
	class ColdPack {price = 2;}; //

	class Rangefinder {price = 4;}; //
	class Laserdesignator {price = 4;}; //

	class optic_Arco {price = 10;}; //
	class optic_Hamr {price = 10;}; //
	class optic_Aco {price = 10;}; //
	class optic_ACO_grn {price = 10;}; //
	class optic_Aco_smg {price = 10;}; //
	class optic_ACO_grn_smg {price = 10;}; //
	class optic_Holosight {price = 10;}; //
	class optic_Holosight_smg {price = 10;}; //
	class optic_SOS {price = 10;}; //
	class optic_MRCO {price = 10;}; //
	class optic_DMS {price = 10;}; //
	class optic_Yorris {price = 10;}; //
	class optic_MRD {price = 10;}; //
	class optic_LRPS {price = 20;}; //
	class optic_NVS {price = 30;}; //
	class optic_Nightstalker {price = 50;}; //
	class optic_tws {price = 20;}; //
	class optic_tws_mg {price = 20;}; //

	// DLC optics
	class optic_AMS { price = 10; }; //
	class optic_AMS_khk { price = 10; }; //
	class optic_AMS_snd { price = 10; }; //
	class optic_KHS_blk { price = 10; }; //
	class optic_KHS_hex { price = 10; }; //
	class optic_KHS_old { price = 10; }; //
	class optic_KHS_tan { price = 10; }; //

	// DLC bipods
	class bipod_01_F_snd { price = 15; }; //
	class bipod_01_F_blk { price = 15; }; //
	class bipod_01_F_mtp { price = 15; }; //
	class bipod_02_F_blk { price = 15; }; //
	class bipod_02_F_tan { price = 15; }; //
	class bipod_02_F_hex { price = 15; }; //
	class bipod_03_F_blk { price = 15; }; //
	class bipod_03_F_oli { price = 15; }; //

	// Epoch
	class Elcan_epoch { price = 5; }; //
	class Elcan_reflex_epoch { price = 10; }; //

	class muzzle_snds_H {price = 5;}; //
	class muzzle_snds_L {price = 5;}; //
	class muzzle_snds_M {price = 5;}; //
	class muzzle_snds_B {price = 5;}; //
	class muzzle_snds_H_MG {price = 5;}; //
	class muzzle_snds_acp {price = 5;}; //
	class Heal_EPOCH {price = 3;}; //
	class Defib_EPOCH {price = 5;}; //
	class Repair_EPOCH {price = 2;}; //

	// DLC muzzles
	class muzzle_snds_338_black { price = 5; }; //
	class muzzle_snds_338_green { price = 5; }; //
	class muzzle_snds_338_sand { price = 5; }; //

	class muzzle_snds_93mmg { price = 5; }; //
	class muzzle_snds_93mmg_tan { price = 5; }; //

	class muzzle_sr25S_epoch { price = 5; }; //

	class PartOreGold {price = 70;}; //
	class PartOreSilver {price = 7;}; //
	class PartOre {price = 1;}; //
	class ItemGoldBar {price = 100;}; //
	class ItemSilverBar {price = 10;}; //
	class ItemGoldBar10oz {price = 1000;}; //
	class ItemTopaz {price = 25;}; //
	class ItemOnyx {price = 30;}; //
	class ItemSapphire {price = 50;}; //
	class ItemAmethyst {price = 25;}; //
	class ItemEmerald {price = 25;}; //
	class ItemCitrine {price = 25;}; //
	class ItemRuby {price = 75;}; //
	class ItemQuartz {price = 5;}; //
	class ItemJade {price = 100;}; //
	class ItemGarnet {price = 25;}; //
	class ItemKiloHemp {price = 100;}; //

	// Building resources
	class PartPlankPack {price = 2;}; //
	class CinderBlocks {price = 20;}; //
	class MortarBucket {price = 20;}; //
	class ItemScraps {price = 2;}; //
	class ItemCorrugated {price = 8;}; //
	class ItemCorrugatedLg {price = 25;}; //

	// Building parts
	class KitStudWall {price = 10;}; //
	class KitWoodFloor {price = 10;}; //
	class KitWoodStairs {price = 10;}; //
	class KitWoodTower {price = 10;}; //
	class KitWoodRamp {price = 14;}; //
	class KitSpikeTrap {price = 25;}; //
	class KitMetalTrap {price = 25;}; //
	class KitTankTrap {price = 25;}; //
	class KitHesco3 { price = 25; }; //
	class KitWoodLadder { price = 10; }; //
	class KitFirePlace {price = 4;}; //
	class KitTiPi {price = 10;}; //
	class KitShelf {price = 90;}; //
	class KitWorkbench { price = 10; }; //

	class KitWoodFoundation { price = 20; }; //
	class KitFoundation {price = 90;}; //
	class KitPlotPole {price = 300;}; //
	class KitSolarGen { price = 200; }; //
	class KitCinderWall {price = 140;}; //

	class ItemSolar { price = 75; }; //
	class ItemCables { price = 50; }; //
	class ItemBattery { price = 50; }; //
	class Pelt_EPOCH {price = 1;}; //
	class Venom_EPOCH {price = 10;}; //

	class HandGrenade_Stone {price = 1;}; //
	class SmokeShell {price = 2;}; //
	class SmokeShellYellow {price = 2;}; //
	class SmokeShellGreen {price = 2;}; //
	class SmokeShellRed {price = 2;}; //
	class SmokeShellPurple {price = 2;}; //
	class SmokeShellOrange {price = 2;}; //
	class SmokeShellBlue {price = 2;}; //
	class Chemlight_green {price = 1;}; //
	class Chemlight_red {price = 1;}; //
	class Chemlight_yellow {price = 1;}; //
	class Chemlight_blue {price = 1;}; //

	class HandGrenade {price = 15;}; //
	class MiniGrenade {price = 10;}; //
	class DemoCharge_Remote_Mag {price = 40;}; //
	class SatchelCharge_Remote_Mag {price = 75;}; //
	class ATMine_Range_Mag {price = 50;}; //
	class ClaymoreDirectionalMine_Remote_Mag {price = 50;}; //
	class APERSMine_Range_Mag {price = 30;}; //
	class APERSBoundingMine_Range_Mag {price = 50;}; //
	class SLAMDirectionalMine_Wire_Mag {price = 40;}; //
	class APERSTripMine_Wire_Mag {price = 30;}; //

	// Backpacks
	class B_AssaultPack_cbr {price = 10;}; //
	class B_AssaultPack_dgtl {price = 10;}; //
	class B_AssaultPack_khk {price = 10;}; //
	class B_AssaultPack_mcamo {price = 10;}; //
	class B_AssaultPack_ocamo {price = 10;}; //
	class B_AssaultPack_rgr {price = 10;}; //
	class B_AssaultPack_sgg {price = 10;}; //
	class B_AssaultPack_blk { price = 10; }; //
	class B_Carryall_cbr {price = 40;}; //
	class B_Carryall_khk {price = 40;}; //
	class B_Carryall_mcamo {price = 40;}; //
	class B_Carryall_ocamo {price = 40;}; //
	class B_Carryall_oli {price = 40;}; //
	class B_Carryall_oucamo {price = 40;}; //
	class B_FieldPack_blk {price = 15;}; //
	class B_FieldPack_cbr {price = 15;}; //
	class B_FieldPack_khk {price = 15;}; //
	class B_FieldPack_ocamo {price = 15;}; //
	class B_FieldPack_oli {price = 15;}; //
	class B_FieldPack_oucamo {price = 15;}; //
	class B_Kitbag_cbr {price = 25;}; //
	class B_Kitbag_mcamo {price = 25;}; //
	class B_Kitbag_rgr {price = 25;}; //
	class B_Kitbag_sgg {price = 25;}; //
	class B_Parachute {price = 25;}; // // no packed option
	class B_TacticalPack_blk {price = 20;}; //
	class B_TacticalPack_mcamo {price = 20;}; //
	class B_TacticalPack_ocamo {price = 20;}; //
	class B_TacticalPack_oli {price = 20;}; //
	class B_TacticalPack_rgr {price = 20;}; //

	class smallbackpack_red_epoch {price = 22;}; //
	class smallbackpack_green_epoch {price = 22;}; //
	class smallbackpack_teal_epoch {price = 22;}; //
	class smallbackpack_pink_epoch {price = 22;}; //
	class I_UAV_01_backpack_F {price = 22;}; //

	class U_O_FullGhillie_lsh { price = 7; }; //
	class U_O_FullGhillie_sard { price = 7; }; //
	class U_O_FullGhillie_ard { price = 7; }; //

	class U_O_CombatUniform_ocamo {price = 5;}; //
	class U_O_GhillieSuit {price = 5;}; //
	class U_O_PilotCoveralls {price = 5;}; //
	class U_O_Wetsuit {price = 5;}; //
	class U_OG_Guerilla1_1 {price = 5;}; //
	class U_OG_Guerilla2_1 {price = 5;}; //
	class U_OG_Guerilla2_2 {price = 5;}; //
	class U_OG_Guerilla2_3 {price = 5;}; //
	class U_OG_Guerilla3_1 {price = 5;}; //
	class U_OG_Guerilla3_2 {price = 5;}; //
	class U_OG_leader {price = 5;}; //

	class U_C_Poloshirt_stripped {price = 4;}; //
	class U_C_Poloshirt_blue {price = 4;}; //
	class U_C_Poloshirt_burgundy {price = 4;}; //
	class U_C_Poloshirt_tricolour {price = 4;}; //
	class U_C_Poloshirt_salmon {price = 4;}; //
	class U_C_Poloshirt_redwhite {price = 4;}; //
	class U_C_Poor_1 {price = 5;}; //
	class U_C_WorkerCoveralls {price = 5;}; //
	class U_C_Journalist {price = 5;}; //
	class U_C_Scientist {price = 5;}; //
	class U_OrestesBody {price = 5;}; //
	class U_Wetsuit_uniform {price = 5;}; //
	class U_Wetsuit_White {price = 5;}; //
	class U_Wetsuit_Blue {price = 5;}; //
	class U_Wetsuit_Purp {price = 5;}; //
	class U_Wetsuit_Camo {price = 5;}; //
	class U_Camo_uniform {price = 5;}; //
	class U_ghillie1_uniform {price = 5;}; //
	class U_ghillie2_uniform {price = 5;}; //
	class U_ghillie3_uniform {price = 5;}; //
	class U_CamoBlue_uniform {price = 5;}; //
	class U_CamoBrn_uniform {price = 5;}; //
	class U_CamoRed_uniform {price = 5;}; //

	class U_C_Driver_1 {price = 5;}; //
	class U_C_Driver_2 {price = 5;}; //
	class U_C_Driver_3 {price = 5;}; //
	class U_C_Driver_4 {price = 5;}; //
	class U_C_Driver_1_black {price = 5;}; //
	class U_C_Driver_1_blue {price = 5;}; //
	class U_C_Driver_1_green {price = 5;}; //
	class U_C_Driver_1_red {price = 5;}; //
	class U_C_Driver_1_white {price = 5;}; //
	class U_C_Driver_1_yellow {price = 5;}; //
	class U_C_Driver_1_orange {price = 5;}; //


	class V_F0_EPOCH { price = 5; }; //
	class V_F1_EPOCH { price = 5; }; //
	class V_F2_EPOCH { price = 5; }; //
	class V_F3_EPOCH { price = 5; }; //
	class V_F4_EPOCH { price = 5; }; //
	class V_F5_EPOCH { price = 5; }; //

	class V_1_EPOCH {price = 5;}; //
	class V_2_EPOCH {price = 5;}; //
	class V_3_EPOCH {price = 5;}; //
	class V_4_EPOCH {price = 5;}; //
	class V_5_EPOCH {price = 5;}; //
	class V_6_EPOCH {price = 5;}; //
	class V_7_EPOCH {price = 5;}; //
	class V_8_EPOCH {price = 5;}; //
	class V_9_EPOCH {price = 5;}; //
	class V_10_EPOCH {price = 5;}; //
	class V_11_EPOCH {price = 5;}; //
	class V_12_EPOCH {price = 5;}; //
	class V_13_EPOCH {price = 5;}; //
	class V_14_EPOCH {price = 5;}; //
	class V_15_EPOCH {price = 5;}; //
	class V_16_EPOCH {price = 5;}; //
	class V_17_EPOCH {price = 5;}; //
	class V_18_EPOCH {price = 5;}; //
	class V_19_EPOCH {price = 5;}; //
	class V_20_EPOCH {price = 5;}; //
	class V_21_EPOCH {price = 5;}; //
	class V_22_EPOCH {price = 5;}; //
	class V_23_EPOCH {price = 5;}; //
	class V_24_EPOCH {price = 5;}; //
	class V_25_EPOCH {price = 5;}; //
	class V_26_EPOCH {price = 5;}; //
	class V_27_EPOCH {price = 5;}; //
	class V_28_EPOCH {price = 5;}; //
	class V_29_EPOCH {price = 5;}; //
	class V_30_EPOCH {price = 5;}; //
	class V_31_EPOCH {price = 5;}; //
	class V_32_EPOCH {price = 5;}; //
	class V_33_EPOCH {price = 5;}; //
	class V_34_EPOCH {price = 5;}; //
	class V_35_EPOCH {price = 5;}; //
	class V_36_EPOCH {price = 5;}; //
	class V_37_EPOCH {price = 5;}; //
	class V_38_EPOCH {price = 5;}; //
	class V_39_EPOCH {price = 5;}; //
	class V_40_EPOCH {price = 5;}; //

	class H_1_EPOCH {price = 3;}; //
	class H_2_EPOCH {price = 3;}; //
	class H_3_EPOCH {price = 3;}; //
	class H_4_EPOCH {price = 3;}; //
	class H_5_EPOCH {price = 3;}; //
	class H_6_EPOCH {price = 3;}; //
	class H_7_EPOCH {price = 3;}; //
	class H_8_EPOCH {price = 3;}; //
	class H_9_EPOCH {price = 3;}; //
	class H_10_EPOCH {price = 3;}; //
	class H_11_EPOCH {price = 3;}; //
	class H_12_EPOCH {price = 3;}; //
	class H_13_EPOCH {price = 3;}; //
	class H_14_EPOCH {price = 3;}; //
	class H_15_EPOCH {price = 3;}; //
	class H_16_EPOCH {price = 3;}; //
	class H_17_EPOCH {price = 3;}; //
	class H_18_EPOCH {price = 3;}; //
	class H_19_EPOCH {price = 3;}; //
	class H_20_EPOCH {price = 3;}; //
	class H_21_EPOCH {price = 3;}; //
	class H_22_EPOCH {price = 3;}; //
	class H_23_EPOCH {price = 3;}; //
	class H_24_EPOCH {price = 3;}; //
	class H_25_EPOCH {price = 3;}; //
	class H_26_EPOCH {price = 3;}; //
	class H_27_EPOCH {price = 3;}; //
	class H_28_EPOCH {price = 3;}; //
	class H_29_EPOCH {price = 3;}; //
	class H_30_EPOCH {price = 3;}; //
	class H_31_EPOCH {price = 3;}; //
	class H_32_EPOCH {price = 3;}; //
	class H_33_EPOCH {price = 3;}; //
	class H_34_EPOCH {price = 3;}; //
	class H_35_EPOCH {price = 3;}; //
	class H_36_EPOCH {price = 3;}; //
	class H_37_EPOCH {price = 3;}; //
	class H_38_EPOCH {price = 3;}; //
	class H_39_EPOCH {price = 3;}; //
	class H_40_EPOCH {price = 3;}; //
	class H_41_EPOCH {price = 3;}; //
	class H_42_EPOCH {price = 3;}; //
	class H_43_EPOCH {price = 3;}; //
	class H_44_EPOCH {price = 3;}; //
	class H_45_EPOCH {price = 3;}; //
	class H_46_EPOCH {price = 3;}; //
	class H_47_EPOCH {price = 3;}; //
	class H_48_EPOCH {price = 3;}; //
	class H_49_EPOCH {price = 3;}; //
	class H_50_EPOCH {price = 3;}; //
	class H_51_EPOCH {price = 3;}; //
	class H_52_EPOCH {price = 3;}; //
	class H_53_EPOCH {price = 3;}; //
	class H_54_EPOCH {price = 3;}; //
	class H_55_EPOCH {price = 3;}; //
	class H_56_EPOCH {price = 3;}; //
	class H_57_EPOCH {price = 3;}; //
	class H_58_EPOCH {price = 3;}; //
	class H_59_EPOCH {price = 3;}; //
	class H_60_EPOCH {price = 3;}; //
	class H_61_EPOCH {price = 3;}; //
	class H_62_EPOCH {price = 3;}; //
	class H_63_EPOCH {price = 3;}; //
	class H_64_EPOCH {price = 3;}; //
	class H_65_EPOCH {price = 3;}; //
	class H_66_EPOCH {price = 3;}; //
	class H_67_EPOCH {price = 3;}; //
	class H_68_EPOCH {price = 3;}; //
	class H_69_EPOCH {price = 3;}; //
	class H_70_EPOCH {price = 3;}; //
	class H_71_EPOCH {price = 3;}; //
	class H_72_EPOCH {price = 3;}; //
	class H_73_EPOCH {price = 3;}; //
	class H_74_EPOCH {price = 3;}; //
	class H_75_EPOCH {price = 3;}; //
	class H_76_EPOCH {price = 3;}; //
	class H_77_EPOCH {price = 3;}; //
	class H_78_EPOCH {price = 3;}; //
	class H_79_EPOCH {price = 3;}; //
	class H_80_EPOCH {price = 3;}; //
	class H_81_EPOCH {price = 3;}; //
	class H_82_EPOCH {price = 3;}; //
	class H_83_EPOCH {price = 3;}; //
	class H_84_EPOCH {price = 3;}; //
	class H_85_EPOCH {price = 3;}; //
	class H_86_EPOCH {price = 3;}; //
	class H_87_EPOCH {price = 3;}; //
	class H_88_EPOCH {price = 3;}; //
	class H_89_EPOCH {price = 3;}; //
	class H_90_EPOCH {price = 3;}; //
	class H_91_EPOCH {price = 3;}; //
	class H_92_EPOCH {price = 3;}; //
	class H_93_EPOCH {price = 3;}; //
	class H_94_EPOCH {price = 5;}; //
	class H_95_EPOCH {price = 5;}; //
	class H_96_EPOCH {price = 5;}; //
	class H_97_EPOCH {price = 5;}; //
	class H_98_EPOCH {price = 5;}; //
	class H_99_EPOCH {price = 5;}; //
	class H_100_EPOCH {price = 5;}; //
	class H_101_EPOCH {price = 5;}; //
	class H_102_EPOCH {price = 5;}; //
	class H_103_EPOCH {price = 5;}; //
	class H_104_EPOCH {price = 3;}; //
	class wolf_mask_epoch {price = 30;}; //
	class pkin_mask_epoch {price = 30;}; //
	class clown_mask_epoch {price = 30;}; //
	
//WEAPONS START	

class ruger_pistol_epoch   {price = 20; tax = 0.5; }; //
class ruger_pistol_epoch_snds_F   {price = 20; tax = 0.5; }; //
class ruger_pistol_epoch_pointer_F   {price = 20; tax = 0.5; }; //
class 1911_pistol_epoch   {price = 20; tax = 0.5; }; //
class hgun_ACPC2_F   {price = 20; tax = 0.5; }; //
class hgun_ACPC2_snds_F   {price = 20; tax = 0.5; }; //
class hgun_P07_F   {price = 20; tax = 0.5; }; //

class hgun_P07_snds_F   {price = 20; tax = 0.5; }; //
class hgun_Pistol_heavy_01_F   {price = 20; tax = 0.5; }; //
class hgun_Pistol_heavy_01_snds_F   {price = 20; tax = 0.5; }; //
class hgun_Pistol_heavy_01_MRD_F   {price = 20; tax = 0.5; }; //
class hgun_Pistol_heavy_02_F   {price = 20; tax = 0.5; }; //
class hgun_Pistol_heavy_02_Yorris_F   {price = 20; tax = 0.5; }; //

class hgun_Rook40_F   {price = 20; tax = 0.5; }; //
class hgun_Rook40_snds_F   {price = 20; tax = 0.5; }; //
class hgun_Pistol_Signal_F   {price = 20; tax = 0.5; }; //
class hgun_P07_khk_F   {price = 20; tax = 0.5; }; //
class hgun_Pistol_01_F   {price = 20; tax = 0.5; }; //
class Hatchet   {price = 30; tax = 0.5; }; //
class CrudeHatchet   {price = 4; tax = 0.5; }; //
class MultiGun   {price = 120; tax = 0.5; }; //
class arifle_Mk20_F   {price = 40; tax = 0.5; }; //
class arifle_Mk20_plain_F   {price = 40; tax = 0.5; }; //
class arifle_Mk20C_F   {price = 40; tax = 0.5; }; //
class arifle_Mk20C_plain_F   {price = 40; tax = 0.5; }; //
class arifle_Mk20_GL_F   {price = 40; tax = 0.5; }; //
class arifle_Mk20_GL_plain_F   {price = 40; tax = 0.5; }; //
class arifle_Mk20C_ACO_F   {price = 45; tax = 0.5; }; //
class arifle_Mk20C_ACO_pointer_F   {price = 50; tax = 0.5; }; //

class arifle_Mk20_pointer_F   {price = 45; tax = 0.5; }; //
class arifle_Mk20_Holo_F   {price = 45; tax = 0.5; }; //
class arifle_Mk20_ACO_F   {price = 45; tax = 0.5; }; //
class arifle_Mk20_ACO_pointer_F   {price = 45; tax = 0.5; }; //
class arifle_Mk20_MRCO_F   {price = 45; tax = 0.5; }; //
class arifle_Mk20_MRCO_plain_F   {price = 45; tax = 0.5; }; //
class arifle_Mk20_MRCO_pointer_F   {price = 50; tax = 0.5; }; //
 
class arifle_Mk20_GL_MRCO_pointer_F   {price = 50; tax = 0.5; }; //
class arifle_Mk20_GL_ACO_F   {price = 45; tax = 0.5; }; //
class arifle_SDAR_F   {price = 45; tax = 0.5; }; //
class arifle_TRG21_F   {price = 45; tax = 0.5; }; //
class arifle_TRG20_F   {price = 45; tax = 0.5; }; //
class arifle_TRG21_GL_F   {price = 45; tax = 0.5; }; //
class arifle_TRG20_Holo_F   {price = 45; tax = 0.5; }; //
class arifle_TRG20_ACO_pointer_F   {price = 50; tax = 0.5; }; //

class arifle_TRG20_ACO_Flash_F   {price = 50; tax = 0.5; }; //Config Error Flashlight! Just here for a note!
class arifle_TRG20_ACO_F   {price = 45; tax = 0.5; }; //
class arifle_TRG21_ACO_pointer_F   {price = 50; tax = 0.5; }; //
class arifle_TRG21_ARCO_pointer_F   {price = 50; tax = 0.5; }; //
class arifle_TRG21_MRCO_F   {price = 45; tax = 0.5; }; //
class arifle_TRG21_GL_MRCO_F   {price = 45; tax = 0.5; }; //

class arifle_TRG21_GL_ACO_pointer_F   {price = 50; tax = 0.5; }; //
class hgun_PDW2000_F   {price = 30; tax = 0.5; }; //
class hgun_PDW2000_snds_F   {price = 35; tax = 0.5; }; //
class hgun_PDW2000_Holo_F   {price = 35; tax = 0.5; }; //
class hgun_PDW2000_Holo_snds_F   {price = 40; tax = 0.5; }; //
class SMG_01_F   {price = 30; tax = 0.5; }; //
class SMG_01_Holo_F   {price = 35; tax = 0.5; }; //
class SMG_01_Holo_pointer_snds_F   {price = 40; tax = 0.5; }; //
 
class SMG_01_ACO_F   {price = 35; tax = 0.5; }; //
class SMG_02_F   {price = 30; tax = 0.5; }; //
class SMG_02_ACO_F   {price = 30; tax = 0.5; }; //
class SMG_02_ARCO_pointg_F   {price = 40; tax = 0.5; }; //
class m4a3_EPOCH   {price = 40; tax = 0.5; }; //
class m16_EPOCH   {price = 40; tax = 0.5; }; //
class m16Red_EPOCH   {price = 40; tax = 0.5; }; //
class m249_EPOCH   {price = 80; tax = 0.5; }; //
class m249Tan_EPOCH   {price = 80; tax = 0.5; }; //
class LMG_03_F   {price = 80; tax = 0.5; }; //
class arifle_AKS_F   {price = 40; tax = 0.5; }; //
class arifle_CTAR_blk_F   {price = 50; tax = 0.5; }; //
 
class arifle_CTAR_hex_F   {price = 50; tax = 0.5; }; //
class arifle_CTAR_ghex_F   {price = 50; tax = 0.5; }; //
class arifle_CTAR_GL_blk_F   {price = 50; tax = 0.5; }; //
class arifle_CTAR_GL_hex_F   {price = 50; tax = 0.5; }; //
class arifle_CTAR_GL_ghex_F   {price = 50; tax = 0.5; }; //
class arifle_CTAR_blk_ACO_Pointer_F   {price = 60; tax = 0.5; }; //
class arifle_CTAR_blk_Pointer_F   {price = 55; tax = 0.5; }; //
 
class arifle_CTAR_blk_ACO_F   {price = 55; tax = 0.5; }; //
class arifle_CTAR_GL_blk_ACO_F   {price = 55; tax = 0.5; }; //
class arifle_CTAR_blk_ARCO_Pointer_F   {price = 60; tax = 0.5; }; //
class arifle_CTAR_blk_ACO_Pointer_Snds_F   {price = 65; tax = 0.5; }; //
class arifle_CTAR_GL_blk_ACO_Pointer_Snds_F   {price = 65; tax = 0.5; }; //
class arifle_CTAR_blk_ARCO_Pointer_Snds_F   {price = 65; tax = 0.5; }; //

class arifle_CTAR_blk_ARCO_F   {price = 55; tax = 0.5; }; //
class arifle_CTARS_blk_F   {price = 50; tax = 0.5; }; //
class arifle_CTARS_hex_F   {price = 50; tax = 0.5; }; //
class arifle_CTARS_ghex_F   {price = 50; tax = 0.5; }; //
class arifle_CTARS_blk_Pointer_F   {price = 55; tax = 0.5; }; //
class arifle_SPAR_01_blk_F   {price = 40; tax = 0.5; }; //
class arifle_SPAR_01_khk_F   {price = 40; tax = 0.5; }; //
 
class arifle_SPAR_01_snd_F   {price = 40; tax = 0.5; }; //
class arifle_SPAR_01_GL_blk_F   {price = 40; tax = 0.5; }; //
class arifle_SPAR_01_GL_khk_F   {price = 40; tax = 0.5; }; //
class arifle_SPAR_01_GL_snd_F   {price = 40; tax = 0.5; }; //
class arifle_SPAR_02_blk_F   {price = 80; tax = 0.5; }; //
class arifle_SPAR_02_khk_F   {price = 80; tax = 0.5; }; //
class arifle_SPAR_02_snd_F   {price = 80; tax = 0.5; }; //
 
class SMG_05_F   {price = 30; tax = 0.5; }; //
class ChainSaw   {price = 200; tax = 0.5; }; //
class ChainSawB   {price = 200; tax = 0.5; }; //
class ChainSawG   {price = 200; tax = 0.5; }; //
class ChainSawP   {price = 200; tax = 0.5; }; //
class ChainSawR   {price = 200; tax = 0.5; }; //
class l85a2_epoch   {price = 40; tax = 0.5; }; //
class l85a2_ris_epoch   {price = 45; tax = 0.5; }; //
class l85a2_ris_ng_epoch   {price = 45; tax = 0.5; }; //
class l85a2_pink_epoch   {price = 40; tax = 0.5; }; //
class l85a2_ugl_epoch   {price = 40; tax = 0.5; }; //
class LMG_Mk200_F   {price = 120; tax = 0.5; }; //
class LMG_Mk200_MRCO_F   {price = 125; tax = 0.5; }; //
class LMG_Mk200_pointer_F   {price = 125; tax = 0.5; }; //
class arifle_Katiba_F   {price = 50; tax = 0.5; }; //
class arifle_Katiba_C_F   {price = 50; tax = 0.5; }; //
class arifle_Katiba_GL_F   {price = 50; tax = 0.5; }; //
class arifle_Katiba_C_ACO_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_Katiba_C_ACO_F   {price = 55; tax = 0.5; }; //
 
class arifle_Katiba_ACO_F   {price = 55; tax = 0.5; }; //
class arifle_Katiba_pointer_F   {price = 55; tax = 0.5; }; //
class arifle_Katiba_ACO_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_Katiba_ARCO_F   {price = 55; tax = 0.5; }; //
class arifle_Katiba_ARCO_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_Katiba_GL_ACO_F   {price = 55; tax = 0.5; }; //
 
class arifle_Katiba_GL_ARCO_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_Katiba_GL_ACO_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_Katiba_GL_Nstalker_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_Katiba_GL_ACO_pointer_snds_F   {price = 65; tax = 0.5; }; //
 
class arifle_Katiba_C_ACO_pointer_snds_F   {price = 65; tax = 0.5; }; //
class arifle_Katiba_ACO_pointer_snds_F   {price = 65; tax = 0.5; }; //
class arifle_Katiba_ARCO_pointer_snds_F   {price = 65; tax = 0.5; }; //
class arifle_MXC_F   {price = 50; tax = 0.5; }; //
class arifle_MX_F   {price = 50; tax = 0.5; }; //
class arifle_MX_GL_F   {price = 50; tax = 0.5; }; //

class arifle_MX_SW_F   {price = 80; tax = 0.5; }; //
class arifle_MXM_F   {price = 50; tax = 0.5; }; //
class arifle_MX_pointer_F   {price = 55; tax = 0.5; }; //
class arifle_MX_Holo_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_Hamr_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_ACO_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_ACO_F   {price = 55; tax = 0.5; }; //
 
class arifle_MX_GL_ACO_F   {price = 55; tax = 0.5; }; //
class arifle_MX_GL_ACO_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_GL_Hamr_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MXC_Holo_F   {price = 55; tax = 0.5; }; //
class arifle_MXC_Holo_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_SW_pointer_F   {price = 85; tax = 0.5; }; //
 
class arifle_MX_SW_Hamr_pointer_F   {price = 90; tax = 0.5; }; //
class arifle_MXM_Hamr_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MXC_ACO_F   {price = 55; tax = 0.5; }; //
class arifle_MXC_Holo_pointer_snds_F   {price = 65; tax = 0.5; }; //
class arifle_MXC_SOS_point_snds_F   {price = 65; tax = 0.5; }; //
 
class arifle_MXC_ACO_pointer_snds_F   {price = 65; tax = 0.5; }; //
class arifle_MXC_ACO_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_ACO_pointer_snds_F   {price = 65; tax = 0.5; }; //
class arifle_MX_RCO_pointer_snds_F   {price = 65; tax = 0.5; }; //
class arifle_MX_GL_Holo_pointer_snds_F   {price = 65; tax = 0.5; }; //
 
class arifle_MXM_SOS_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MXM_RCO_pointer_snds_F   {price = 60; tax = 0.5; }; //
class arifle_MXM_DMS_F   {price = 60; tax = 0.5; }; //
class arifle_MXC_Black_F   {price = 50; tax = 0.5; }; //
class arifle_MX_Black_F   {price = 50; tax = 0.5; }; //
class arifle_MX_GL_Black_F   {price = 50; tax = 0.5; }; //
 
class arifle_MX_SW_Black_F   {price = 80; tax = 0.5; }; //
class arifle_MXM_Black_F   {price = 50; tax = 0.5; }; //
class arifle_MX_GL_Black_Hamr_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_Black_Hamr_pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_SW_Black_Hamr_pointer_F   {price = 60; tax = 0.5; }; //
 
class LMG_Mk200_LP_BI_F   {price = 125; tax = 0.5; }; //
class LMG_Mk200_BI_F   {price = 125; tax = 0.5; }; //
class arifle_MXM_DMS_LP_BI_snds_F   {price = 70; tax = 0.5; }; //
class arifle_MXM_Hamr_LP_BI_F   {price = 65; tax = 0.5; }; //
class arifle_MX_khk_F   {price = 50; tax = 0.5; }; //
class arifle_MX_khk_ACO_Pointer_F   {price = 60; tax = 0.5; }; //
 
class arifle_MX_khk_Holo_Pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_khk_Hamr_Pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_khk_Hamr_Pointer_Snds_F   {price = 65; tax = 0.5; }; //
class arifle_MX_khk_Pointer_F   {price = 55; tax = 0.5; }; //
class arifle_MX_khk_ACO_Pointer_Snds_F   {price = 65; tax = 0.5; }; //

class arifle_MX_GL_khk_F   {price = 50; tax = 0.5; }; //
class arifle_MX_GL_khk_ACO_F   {price = 55; tax = 0.5; }; //
class arifle_MX_GL_khk_Hamr_Pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MX_GL_khk_Holo_Pointer_Snds_F   {price = 65; tax = 0.5; }; //
class arifle_MX_SW_khk_F   {price = 80; tax = 0.5; }; //
 
class arifle_MX_SW_khk_Pointer_F   {price = 85; tax = 0.5; }; //
class arifle_MXC_khk_F   {price = 50; tax = 0.5; }; //
class arifle_MXC_khk_Holo_Pointer_F   {price = 60; tax = 0.5; }; //
class arifle_MXC_khk_ACO_F   {price = 55; tax = 0.5; }; //
class arifle_MXC_khk_ACO_Pointer_Snds_F   {price = 65; tax = 0.5; }; //
 
class arifle_MXM_khk_F   {price = 50; tax = 0.5; }; //
class arifle_MXM_khk_MOS_Pointer_Bipod_F   {price = 65; tax = 0.5; }; //
class srifle_DMR_07_blk_F   {price = 60; tax = 0.5; }; //
class srifle_DMR_07_hex_F   {price = 60; tax = 0.5; }; //
class srifle_DMR_07_ghex_F   {price = 60; tax = 0.5; }; //
class srifle_DMR_07_blk_DMS_F   {price = 65; tax = 0.5; }; //
 
class srifle_DMR_07_blk_DMS_Snds_F   {price = 70; tax = 0.5; }; //
class arifle_AK12_F   {price = 80; tax = 0.5; }; //
class arifle_AK12_GL_F   {price = 80; tax = 0.5; }; //
class arifle_AKM_F   {price = 80; tax = 0.5; }; //
class arifle_ARX_blk_F   {price = 80; tax = 0.5; }; //
class arifle_ARX_ghex_F   {price = 80; tax = 0.5; }; //
class arifle_ARX_hex_F   {price = 80; tax = 0.5; }; //
class Rollins_F   {price = 30; tax = 0.5; }; //
class srifle_DMR_01_F   {price = 80; tax = 0.5; }; //
class srifle_DMR_01_ACO_F   {price = 85; tax = 0.5; }; //
class srifle_DMR_01_MRCO_F   {price = 85; tax = 0.5; }; //
class srifle_DMR_01_SOS_F   {price = 85; tax = 0.5; }; //
class srifle_DMR_01_DMS_F   {price = 85; tax = 0.5; }; //
class srifle_DMR_01_DMS_snds_F   {price = 90; tax = 0.5; }; //
class srifle_DMR_01_ARCO_F   {price = 80; tax = 0.5; }; //
 
class srifle_EBR_F   {price = 80; tax = 0.5; }; //
class srifle_EBR_ACO_F   {price = 85; tax = 0.5; }; //
class srifle_EBR_MRCO_pointer_F   {price = 90; tax = 0.5; }; //
class srifle_EBR_ARCO_pointer_F   {price = 90; tax = 0.5; }; //
class srifle_EBR_SOS_F   {price = 85; tax = 0.5; }; //
class srifle_EBR_ARCO_pointer_snds_F   {price = 95; tax = 0.5; }; //
class srifle_EBR_DMS_F   {price = 85; tax = 0.5; }; //
 
class srifle_EBR_Hamr_pointer_F   {price = 90; tax = 0.5; }; //
class srifle_EBR_DMS_pointer_snds_F   {price = 95; tax = 0.5; }; //
class srifle_GM6_F   {price = 150; tax = 0.5; }; //
class srifle_GM6_SOS_F   {price = 155; tax = 0.5; }; //
class srifle_GM6_LRPS_F   {price = 155; tax = 0.5; }; //
class srifle_GM6_camo_F   {price = 150; tax = 0.5; }; //
class srifle_GM6_camo_SOS_F   {price = 155; tax = 0.5; }; //
 
class srifle_GM6_camo_LRPS_F   {price = 155; tax = 0.5; }; //
class srifle_LRR_F   {price = 150; tax = 0.5; }; //
class srifle_LRR_SOS_F   {price = 155; tax = 0.5; }; //
class srifle_LRR_LRPS_F   {price = 155; tax = 0.5; }; //
class srifle_LRR_camo_F   {price = 150; tax = 0.5; }; //
class srifle_LRR_camo_SOS_F   {price = 155; tax = 0.5; }; //
class srifle_LRR_camo_LRPS_F   {price = 155; tax = 0.5; }; //
class LMG_Zafir_F   {price = 120; tax = 0.5; }; //
 
class LMG_Zafir_pointer_F   {price = 125; tax = 0.5; }; //
class LMG_Zafir_ARCO_F   {price = 125; tax = 0.5; }; //
class AKM_EPOCH   {price = 80; tax = 0.5; }; //
class M14_EPOCH   {price = 80; tax = 0.5; }; //
class M14Grn_EPOCH   {price = 80; tax = 0.5; }; //
class m107_EPOCH   {price = 150; tax = 0.5; }; //
class m107Tan_EPOCH   {price = 150; tax = 0.5; }; //
class srifle_DMR_01_DMS_BI_F   {price = 90; tax = 0.5; }; //
class srifle_DMR_01_DMS_snds_BI_F   {price = 95; tax = 0.5; }; // 

class srifle_DMR_02_F   {price = 150; tax = 0.5; }; //
class srifle_DMR_02_camo_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_02_sniper_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_02_ACO_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_02_MRCO_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_02_SOS_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_02_DMS_F   {price = 155; tax = 0.5; }; //
 
class srifle_DMR_02_sniper_AMS_LP_S_F   {price = 165; tax = 0.5; }; //
class srifle_DMR_02_camo_AMS_LP_F   {price = 160; tax = 0.5; }; //
class srifle_DMR_02_ARCO_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_03_F   {price = 80; tax = 0.5; }; //
class srifle_DMR_03_khaki_F   {price = 80; tax = 0.5; }; //
class srifle_DMR_03_tan_F   {price = 80; tax = 0.5; }; //
 
class srifle_DMR_03_multicam_F   {price = 80; tax = 0.5; }; //
class srifle_DMR_03_woodland_F   {price = 80; tax = 0.5; }; //
class srifle_DMR_03_ACO_F   {price = 85; tax = 0.5; }; //
class srifle_DMR_03_MRCO_F   {price = 85; tax = 0.5; }; //
class srifle_DMR_03_SOS_F   {price = 85; tax = 0.5; }; //
class srifle_DMR_03_DMS_F   {price = 85; tax = 0.5; }; //
 
class srifle_DMR_03_tan_AMS_LP_F   {price = 95; tax = 0.5; }; //
class srifle_DMR_03_DMS_snds_F   {price = 90; tax = 0.5; }; //
class srifle_DMR_03_ARCO_F   {price = 85; tax = 0.5; }; //
class srifle_DMR_03_AMS_F   {price = 85; tax = 0.5; }; //
class srifle_DMR_04_F   {price = 100; tax = 0.5; }; //
class srifle_DMR_04_Tan_F   {price = 100; tax = 0.5; }; //
class srifle_DMR_04_ACO_F   {price = 105; tax = 0.5; }; //
 
class srifle_DMR_04_MRCO_F   {price = 105; tax = 0.5; }; //
class srifle_DMR_04_SOS_F   {price = 105; tax = 0.5; }; //
class srifle_DMR_04_DMS_F   {price = 105; tax = 0.5; }; //
class srifle_DMR_04_ARCO_F   {price = 105; tax = 0.5; }; //
class srifle_DMR_04_NS_LP_F   {price = 110; tax = 0.5; }; //
class srifle_DMR_05_blk_F   {price = 150; tax = 0.5; }; //
class srifle_DMR_05_hex_F   {price = 150; tax = 0.5; }; //
 
class srifle_DMR_05_tan_f   {price = 150; tax = 0.5; }; //
class srifle_DMR_05_ACO_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_05_MRCO_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_05_SOS_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_05_DMS_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_05_KHS_LP_F   {price = 160; tax = 0.5; }; //
class srifle_DMR_05_DMS_snds_F   {price = 160; tax = 0.5; }; //
 
class srifle_DMR_05_ARCO_F   {price = 155; tax = 0.5; }; //
class srifle_DMR_06_camo_F   {price = 80; tax = 0.5; }; //
class srifle_DMR_06_olive_F   {price = 80; tax = 0.5; }; //
class srifle_DMR_06_camo_khs_F   {price = 85; tax = 0.5; }; //
class srifle_EBR_MRCO_LP_BI_F   {price = 95; tax = 0.5; }; //
class MMG_01_hex_F   {price = 150; tax = 0.5; }; //
class MMG_01_tan_F   {price = 150; tax = 0.5; }; //
 
class MMG_01_hex_ARCO_LP_F   {price = 160; tax = 0.5; }; //
class MMG_02_camo_F   {price = 150; tax = 0.5; }; //
class MMG_02_black_F   {price = 150; tax = 0.5; }; //
class MMG_02_sand_F   {price = 150; tax = 0.5; }; //
class MMG_02_sand_RCO_LP_F   {price = 160; tax = 0.5; }; //
class MMG_02_black_RCO_BI_F   {price = 160; tax = 0.5; }; //
class srifle_LRR_tna_F   {price = 150; tax = 0.5; }; //
class srifle_LRR_tna_LRPS_F   {price = 155; tax = 0.5; }; //
 
class srifle_GM6_ghex_F   {price = 150; tax = 0.5; }; //
class srifle_GM6_ghex_LRPS_F   {price = 155; tax = 0.5; }; //
class arifle_SPAR_03_blk_F   {price = 80; tax = 0.5; }; //
class arifle_SPAR_03_khk_F   {price = 80; tax = 0.5; }; //
class arifle_SPAR_03_snd_F   {price = 80; tax = 0.5; }; //
class speargun_epoch   {price = 50; tax = 0.5; }; //
class sr25_epoch   {price = 80; tax = 0.5; }; //
class sr25_ec_epoch   {price = 80; tax = 0.5; }; // 
 
class MeleeSledge   {price = 50; tax = 0.5; }; //
class MeleeSword   {price = 125; tax = 0.5; }; //
class MeleeMaul   {price = 6; tax = 0.5; }; //
class WoodClub   {price = 4; tax = 0.5; }; //
class MeleeRod   {price = 4; tax = 0.5; }; //
class Plunger   {price = 10; tax = 0.5; }; //
 
class launch_RPG32_F   {price = 5000; tax = 0.5; }; //
class launch_RPG32_ghex_F   {price = 5000; tax = 0.5; }; //
class launch_RPG7_F   {price = 5000; tax = 0.5; }; //
class launch_NLAW_F   {price = 5000; tax = 0.5; }; //
class launch_B_Titan_F   {price = 5000; tax = 0.5; }; //
class launch_I_Titan_F   {price = 5000; tax = 0.5; }; //
class launch_O_Titan_F   {price = 5000; tax = 0.5; }; //
class launch_B_Titan_short_F   {price = 5000; tax = 0.5; }; //
class launch_I_Titan_short_F   {price = 5000; tax = 0.5; }; //
class launch_O_Titan_short_F   {price = 5000; tax = 0.5; }; //
class launch_B_Titan_tna_F   {price = 5000; tax = 0.5; }; //
class launch_B_Titan_short_tna_F   {price = 5000; tax = 0.5; }; //
class launch_O_Titan_ghex_F   {price = 5000; tax = 0.5; }; //
class launch_O_Titan_short_ghex_F   {price = 5000; tax = 0.5; }; //

//MAGAZINES START

class 10rnd_22X44_magazine   {price = 6; tax = 0.5; }; //
class 9rnd_45X88_magazine   {price = 6; tax = 0.5; }; //
class 9Rnd_45ACP_Mag   {price = 6; tax = 0.5; }; //
class 16Rnd_9x21_Mag   {price = 6; tax = 0.5; }; //
class 16Rnd_9x21_red_Mag   {price = 6; tax = 0.5; }; //
class 16Rnd_9x21_green_Mag   {price = 6; tax = 0.5; }; //
class 16Rnd_9x21_yellow_Mag   {price = 6; tax = 0.5; }; //
class 30Rnd_9x21_Mag   {price = 8; tax = 0.5; }; //
class 30Rnd_9x21_Red_Mag   {price = 8; tax = 0.5; }; //
class 30Rnd_9x21_Yellow_Mag   {price = 8; tax = 0.5; }; //
class 30Rnd_9x21_Green_Mag   {price = 8; tax = 0.5; }; //
class 11Rnd_45ACP_Mag   {price = 6; tax = 0.5; }; //
class 6Rnd_45ACP_Cylinder   {price = 6; tax = 0.5; }; //
class 6Rnd_GreenSignal_F   {price = 6; tax = 0.5; }; //
class 6Rnd_RedSignal_F   {price = 6; tax = 0.5; }; //
class 10Rnd_9x21_Mag   {price = 6; tax = 0.5; }; //
class hatchet_swing   {price = 2; tax = 0.5; }; //
class EnergyPack   {price = 100; tax = 0.5; }; //
class EnergyPackLg   {price = 1000; tax = 0.5; }; //
class 30Rnd_556x45_Stanag   {price = 10; tax = 0.5; }; //
class 30Rnd_556x45_Stanag_Tracer_Red   {price = 10; tax = 0.5; }; //
class 30Rnd_556x45_Stanag_Tracer_Green   {price = 10; tax = 0.5; }; //
class 30Rnd_556x45_Stanag_Tracer_Yellow   {price = 10; tax = 0.5; }; //
class 30Rnd_556x45_Stanag_red   {price = 10; tax = 0.5; }; //
class 30Rnd_556x45_Stanag_green   {price = 10; tax = 0.5; }; //
class 30Rnd_45ACP_Mag_SMG_01   {price = 8; tax = 0.5; }; //
class 30Rnd_45ACP_Mag_SMG_01_tracer_green   {price = 8; tax = 0.5; }; //
class 30Rnd_45ACP_Mag_SMG_01_Tracer_Red   {price = 8; tax = 0.5; }; //
class 30Rnd_45ACP_Mag_SMG_01_Tracer_Yellow   {price = 8; tax = 0.5; }; //
class 30Rnd_9x21_Mag_SMG_02   {price = 8; tax = 0.5; }; //
class 30Rnd_9x21_Mag_SMG_02_Tracer_Red   {price = 8; tax = 0.5; }; //
class 30Rnd_9x21_Mag_SMG_02_Tracer_Yellow   {price = 8; tax = 0.5; }; //
class 30Rnd_9x21_Mag_SMG_02_Tracer_Green   {price = 8; tax = 0.5; }; //
class 20Rnd_556x45_UW_mag   {price = 10; tax = 0.5; }; //
class 200Rnd_556x45_M249   {price = 50; tax = 0.5; }; //
class 200Rnd_556x45_Box_F   {price = 50; tax = 0.5; }; //
class 200Rnd_556x45_Box_Red_F   {price = 50; tax = 0.5; }; //
class 200Rnd_556x45_Box_Tracer_F   {price = 50; tax = 0.5; }; //
class 200Rnd_556x45_Box_Tracer_Red_F   {price = 50; tax = 0.5; }; //
class 30Rnd_545x39_Mag_F   {price = 10; tax = 0.5; }; //
class 30Rnd_545x39_Mag_Green_F   {price = 10; tax = 0.5; }; //
class 30Rnd_545x39_Mag_Tracer_F   {price = 10; tax = 0.5; }; //
class 30Rnd_545x39_Mag_Tracer_Green_F   {price = 10; tax = 0.5; }; //
class 30Rnd_580x42_Mag_F   {price = 10; tax = 0.5; }; //
class 30Rnd_580x42_Mag_Tracer_F   {price = 10; tax = 0.5; }; //
class 100Rnd_580x42_Mag_F   {price = 10; tax = 0.5; }; //
class 100Rnd_580x42_Mag_Tracer_F   {price = 10; tax = 0.5; }; //
class 150Rnd_556x45_Drum_Mag_F   {price = 40; tax = 0.5; }; //
class 150Rnd_556x45_Drum_Mag_Tracer_F   {price = 40; tax = 0.5; }; //
class CSGAS   {price = 50; tax = 0.5; }; //
class 200Rnd_65x39_cased_Box   {price = 100; tax = 0.5; }; //
class 200Rnd_65x39_cased_Box_Tracer   {price = 100; tax = 0.5; }; //
class 30Rnd_65x39_caseless_green   {price = 60; tax = 0.5; }; //
class 30Rnd_65x39_caseless_green_mag_Tracer   {price = 60; tax = 0.5; }; //
class 30Rnd_65x39_caseless_mag   {price = 60; tax = 0.5; }; //
class 30Rnd_65x39_caseless_mag_Tracer   {price = 60; tax = 0.5; }; //
class 100Rnd_65x39_caseless_mag_Tracer   {price = 80; tax = 0.5; }; //
class 100Rnd_65x39_caseless_mag   {price = 80; tax = 0.5; }; //
class 20Rnd_650x39_Cased_Mag_F   {price = 60; tax = 0.5; }; //
class 30Rnd_762x39_Mag_F   {price = 80; tax = 0.5; }; //
class 30Rnd_762x39_Mag_Green_F   {price = 80; tax = 0.5; }; //
class 30Rnd_762x39_Mag_Tracer_F   {price = 80; tax = 0.5; }; //
class 30Rnd_762x39_Mag_Tracer_Green_F   {price = 80; tax = 0.5; }; //
class 5Rnd_rollins_mag   {price = 12; tax = 0.5; }; //
class 10Rnd_762x54_Mag   {price = 60; tax = 0.5; }; //
class 20Rnd_762x51_Mag   {price = 60; tax = 0.5; }; //
class 5Rnd_127x108_Mag   {price = 120; tax = 0.5; }; //
class 5Rnd_127x108_APDS_Mag   {price = 120; tax = 0.5; }; //
class 7Rnd_408_Mag   {price = 120; tax = 0.5; }; //
class 150Rnd_762x54_Box   {price = 120; tax = 0.5; }; //
class 150Rnd_762x54_Box_Tracer   {price = 120; tax = 0.5; }; //
class 30Rnd_762x39_Mag   {price = 80; tax = 0.5; }; //
class 10Rnd_338_Mag   {price = 80; tax = 0.5; }; //
class 10Rnd_127x54_Mag   {price = 80; tax = 0.5; }; //
class 10Rnd_93x64_DMR_05_Mag   {price = 80; tax = 0.5; }; //
class 150Rnd_93x64_Mag   {price = 120; tax = 0.5; }; //
class 130Rnd_338_Mag   {price = 120; tax = 0.5; }; //
class spear_magazine   {price = 20; tax = 0.5; }; //
class RPG32_F   {price = 2000; tax = 0.5; }; //
class RPG32_HE_F   {price = 2000; tax = 0.5; }; //
class RPG7_F   {price = 2000; tax = 0.5; }; //
class sledge_swing   {price = 2; tax = 0.5; }; //
class stick_swing   {price = 2; tax = 0.5; }; //
class NLAW_F   {price = 2000; tax = 0.5; }; //
class Titan_AA   {price = 2000; tax = 0.5; }; //
class Titan_AT   {price = 2000; tax = 0.5; }; //
class Titan_AP   {price = 2000; tax = 0.5; }; //
class 10rnd_50BW_Mag_F   {price = 60; tax = 0.5; }; //


}; //
