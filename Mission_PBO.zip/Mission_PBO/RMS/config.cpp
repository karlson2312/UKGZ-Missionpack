class CfgPatches {
	class RMS {
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] = {"A3_server_settings"};
	};
};
class CfgFunctions {
	class RMS {
		class main {
			file = "x\addons\rms";
			class init {
				postInit = 1;
			};
		};
	};
};